*TOLONG INGET UNTUK INI*

Inget untuk install FontAwesome

"npm install Font Awesome"
