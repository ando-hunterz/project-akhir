import { authTkn } from './../shared/model/loginDetails';
import { MahasiswaApiService } from './../shared/services/mahasiswa-api.service';
import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { first } from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';
import { transition, trigger, style, animate } from '@angular/animations';

@Component({
  selector : 'app-register',
  templateUrl : './register.component.html',
  styleUrls : ['./register.component.scss'],
  animations: [
    trigger(
      'inOutAnimation',
      [
        transition(
          ':enter',
          [
            style({ opacity: 0}),
            animate('1s ease-out',
            style({ opacity: 1}))
          ]
        )
      ]
    ),
    trigger('myInsertRemoveTrigger', [
      transition(':enter', [
        style({
          opacity: 0,
        }),
        animate('1s ease-in', style({ opacity: 1})),
      ])
    ]),
  ]
})
export class RegisterComponent implements OnInit {

  registerDetail = new registerDetail('', '', '', '', '', '', '', '' );

  public authTkn: authTkn = null;
  // tslint:disable-next-line: variable-name
  public user_name: string;
  public fullname: string;
  public telepon: string;
  public password: string;
  public email: string;
  public alamat: string;
  // tslint:disable-next-line: variable-name
  public foto_profil: string;
  public birthdate: string;

  registerForm = this.fb..group({
    user_name: ['', Validators.required],
    fullname: ['', Validators.required],
    telepon: ['', Validators.required],
    email: ['', Validators.required],
    alamat: ['', Validators.required],
    birthdate: ['', Validators.required],
    foto_profil: ['', Validators.required],
    password: ['', Validators.required],
  });


constructor(private mahasiswaApi: MahasiswaApiService, private route: Router, private fb: FormBuilder) { }

get this.user_name() {
  return this.registerForm.controls.user_name;

get this.password() {
    return this.registerForm.controls.password;
  }

get this.fullname() {
  return this.registerForm.controls.fullname;

get this.telepon() {
    return this.registerForm.controls.telepon;
  }

get email() {
  return this.registerForm.controls.email;

get alamat(){
    return this.registerForm.controls.alamat;
  }

get birthdate() {
    return this.registerForm.controls.birthdate;

get foto_profil() {
    return this.registerForm.controls.foto_profil;
  }

ngOnInit() {
  }


onSubmit() {
    this.registerForm.controls.password.patchValue(
      CryptoJS.SHA512(this.registerForm.value.password).toString()
    );
    console.log(this.registerForm.value);
    this.mahasiswaApi.postUserRegister(this.registerForm.value).subscribe(
      res => {
        console.log(res);
        this.authTkn = res;
        console.log(this.authTkn);
        localStorage.setItem('token', this.authTkn.token);
        this.mahasiswaApi.getCurrentToken();
        this.route.navigate(['/hompage']);
        alert(this.authTkn.info);
      },
      error => {
        console.log(error);
        alert(error.error.message);
      }
    );
  }
}

